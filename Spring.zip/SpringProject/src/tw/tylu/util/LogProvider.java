package tw.tylu.util;

public class LogProvider {
	
	public void log(String msg) {
		System.out.println("msg: "+msg);
		
	}

}
